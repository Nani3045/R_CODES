#### Additional functions used ###########
variable_finder<-function(expr){
  
  names<-paste0('x',1:60)
  names2<-paste0('\\b',names,'\\b')
  
  n<-list()
  
  for (i in 1:length(names2)){
    
    n[[i]]<-grepl(names2[i],expr)
    
  }
  
  cn<-colnames(dm2)[unlist(n)]
  
  return(cn)
  
  
}