#### Function for hyper parameter optimization



hp_opt3<- function (type,dim,size,split,dm2,func,y){
  # 
  # if(type=="Kung"){
  #   
  #   dm<- design_kung(dim,size,split)[[1]]
  # }   else if (type=="KungMP"){
  #   
  #   
  #   dm<- design_kungMP(dim,size,split)[[1]]
  #   
  # } else if (type=="KungSLHD"){
  #   
  #   dm<- design_kungSLHD(dim,size,split)[[1]]
  #   
  #   
  # } else if (type=="Martinez"){
  #   
  #   
  #   dm<- design_martinez(dim,size,split,nfour=3)[[1]]
  #   
  #   
  # } else if (type=="MartinezMP"){
  #   
  #   dm<- design_martinezMP(dim,size,split,nfour=3)[[1]]
  #   
  # } else if (type=="MartinezSLHD"){
  #   
  #   dm<- design_martinezSLHD(dim,size,split,nfour=3)[[1]]
  #   
  # } else if(type=="MaxproQQ") {
  #   
  #   dm<- design_mpqq(dim,size,split,nfour=3)[[1]]
  #   
  # } else if (type=="CoC"){
  #   
  #   dm<-design_coc(dim,size,split)
  #   
  # }  else if (type=="MC_unif"){
  #   
  #   dm<-design_mc_unif(dim,size,split)[[1]]
  #   
  # } else if (type=="MC_beta"){
  #   
  #   dm<-design_mc_beta(dim,size,split)[[1]]
  #   
  # } else (print("Wrong design type entered"))
  # 
  # 
  # colnames(dm)<-paste0('x',1:ncol(dm))
  # 
  
  ##### Splitting cont and categ features of data matrix
  num_col_tuning<-c()   # Numeric columns
  
  for (i in 1:ncol(dm2)){
    
    num_col_tuning[i]<- is.numeric(dm2[,i])
    
  }
  cont_col_tuning<- dm2[,num_col_tuning]
  
  fact_col_tuning<-c()  # Factor columns
  
  for (i in 1:ncol(dm2)){
    
    fact_col_tuning[i]<- is.factor(dm2[,i])
    
  }
  
  categ_col_tuning<- dm2[,fact_col_tuning]
  
  
  #Changing to 0,1 level (in accordance to glinternet)
  
  # for (i in 1:ncol(categ_col_tuning)){
  #   
  #   if(nlevels(categ_col_tuning[,i])==2){
  #     
  #     levels(categ_col_tuning[,i])<-c(0,1)
  #   } else{levels(categ_col_tuning[,i])<-c(0,1,2,3)}
  # }
  # 
  
  
  cont_col_tuning<-cont_col_tuning[,sample(1:ncol(cont_col_tuning),ncol(cont_col_tuning))]
  categ_col_tuning_sampled<-categ_col_tuning[,sample(1:(ncol(categ_col_tuning)-3),ncol(categ_col_tuning)-3)]
  
  categ_col_tuning<-cbind(categ_col_tuning_sampled,categ_col_tuning[,(ncol(categ_col_tuning)-2):ncol(categ_col_tuning)])
  
  
  
  
  dm2_tuning<- cbind(cont_col_tuning,categ_col_tuning)    #Design matrix changed to 0,1 factor level
  colnames(dm2_tuning)<-paste0('x',1:ncol(dm2_tuning))
  
  
  # num_col_tuning<-c()   # Numeric columns
  # 
  # for (i in 1:ncol(dm2_tuning)){
  #   
  #   num_col_tuning[i]<- is.numeric(dm2_tuning[,i])
  #   
  # }
  # 
  # cont_col_tuning<- dm2_tuning[,num_col_tuning]
  # 
  # fact_col_tuning<-c()  # Factor columns
  # 
  # for (i in 1:ncol(dm2_tuning)){
  #   
  #   fact_col_tuning[i]<- is.factor(dm2_tuning[,i])
  #   
  # }
  # 
  # categ_col_tuning<- dm2_tuning[,fact_col_tuning]
  # c4<-categ_col_tuning[,(ncol(categ_col_tuning)-2):ncol(categ_col_tuning)]
  # categ_col_tuning<-categ_col_tuning[,1:(ncol(categ_col_tuning)-3)]
  # 
  # 
  # cont_col2_tuning<-cont_col_tuning[,sample(ncol(cont_col_tuning))] #Randomizing numeric columns
  # categ_col2_tuning<-categ_col_tuning[,sample(ncol(categ_col_tuning))] #Randomizing factor columns
  # 
  #test_design_parameters<- cbind(cont_col2_tuning,categ_col2_tuning,c4)
  
  test_design_parameters<-dm2_tuning
  colnames(test_design_parameters)<-paste0('x',1:ncol(test_design_parameters))
  
  
  ## Response simulation for tuning dataset
  tuning_resp<- with(test_design_parameters,eval(parse(text=func)))  # response values for tuning
  
  # snr2<-25
  # sigma2 <- sqrt(var(tuning_resp)/snr2)
  # 
  # 
  # tuning_resp2<-tuning_resp+rnorm(nrow(dm2),0,sigma2)
  # 
  
  tuning_resp2<-tuning_resp
  
  
  ### Fitting group lasso to find opt hyper parameter #####
  
  
  ncont_tuning<- ncol(cont_col_tuning)
  ncat_tuning<- (ncont_tuning+1):ncol(test_design_parameters)
  grp_cat_tuning<-list()
  
  for (i in ncat_tuning){
    
    grp_cat_tuning[[i]]<- rep(i,nlevels(test_design_parameters[,i]))
    
  }
  
  un_grp_cat_tuning<- unlist(grp_cat_tuning)
  
  grp_tuning<- c(1:ncont_tuning,un_grp_cat_tuning)
  
  suppressWarnings(dummy_tuning_data<- dummy.data.frame(test_design_parameters))
  
  dummy_tuning_data<- as.matrix(dummy_tuning_data)
  
  suppressWarnings(dummy_dm<-dummy.data.frame(dm2))
  
  glasso_tuning<- gglasso(dummy_tuning_data,tuning_resp2,group=grp_tuning,loss="ls")
  
  t<-glasso_tuning$beta
  err<-c()
  
  pr1<- predict(glasso_tuning,dummy_dm,type = "link")
  
  
  for (i in 1:ncol(pr1)){
    
    err[i]<- MSE(pr1[,i],y)
    
  }
  
  mincvlambda<- which.min(err)  #index of lambda with minimum CV
  
  #threshold<- err[mincvlambda]+std.error(err)  # treshold for 1SE
  
  # threshold<- err[mincvlambda]  # treshold for 1SE
  # 
  #lv<- err>threshold     #Comparing err with treshold value
  # 
  #oneSElambda<- min(which(lv==TRUE))   # index of optimum lambda from 1se rule
  
  
  # Opt value
  #lambda_value_glasso<- glasso_tuning$lambda[oneSElambda]   # Opt lambda value
  lambda_value_glasso<- glasso_tuning$lambda[mincvlambda]   # Opt lambda value
  
  
  
  ### Fitting glinternet to find opt hyper parameter #####
  
  numlevels_tuning<-c()  # numlevel for glinternet
  
  for (i in 1:ncol(test_design_parameters)){
    if (class(test_design_parameters[,i])=="numeric"){
      
      numlevels_tuning[i]<- 1
      
    } else {numlevels_tuning[i]<- nlevels(test_design_parameters[,i])}
    
  }
  
  
  # Converting to glinternet input form
  for(i in 1:ncol(test_design_parameters)){
    
    test_design_parameters[,i]<- as.numeric(as.character(test_design_parameters[,i]))
    
  }
  
  glnet_tuning<-glinternet(test_design_parameters,tuning_resp2,numlevels_tuning)
  
  pr2<- predict(glnet_tuning,dm2)
  
  err2<-c()
  
  
  
  for (i in 1:ncol(pr2)){
    
    err2[i]<- MSE(pr2[,i],y)
    
  }
  
  mincvlambda2<- which.min(err2)  #index of lambda with minimum CV
  
  #threshold2<- err2[mincvlambda2]+std.error(err2)/4  # treshold for 1SE
  
  # threshold2<- err2[mincvlambda2]  # treshold for 1SE
  # 
  # lv2<- err2<threshold2     #Comparing err with treshold value
  # 
  # oneSElambda2<- min(which(lv2==TRUE))   # index of optimum lambda from 1se rule
  
  
  # Opt value
  #lambda_value_glnet<- glnet_tuning$lambda[oneSElambda2]   # Opt lambda value
  lambda_value_glnet<- glnet_tuning$lambda[mincvlambda2]   # Opt lambda value
  
  
  
  
  ##### For Boosted Trees ##########
  
  gbmGrid_tuning <-  expand.grid(n.trees =c(100,500),interaction.depth=2, shrinkage = c(0.01,0.1),n.minobsinnode=10)
  
  tuned_gbm<-train(test_design_parameters,tuning_resp2,method = "gbm",tuneGrid=gbmGrid_tuning,verbose=FALSE)
  
  best_parameters_gbm<- tuned_gbm$bestTune
  
  
  opt_parameters<- list(lambda_value_glasso,lambda_value_glnet,best_parameters_gbm)
  
  return(opt_parameters)
  
}













variable_finder<-function(expr){
  
  names<-paste0('x',1:60)
  names2<-paste0('\\b',names,'\\b')
  
  n<-list()
  
  for (i in 1:length(names2)){
    
    n[[i]]<-grepl(names2[i],expr)
    
  }
  
  cn<-colnames(dm2)[unlist(n)]
  
  if(length(cn)>1){
    
    op<-mult(cn)
    
  } else{op<-cn}
  
  return(op)
  
  
  
}






loc<- function(expr){
  
  op1<- which(strsplit(expr, "")[[1]]=="x")
  
  if (length(op1)==1){
    op2<- substr(expr,op1,op1+1)
  } else {
    
    op2<-c()
    
    for(i in 1:length(op1)){
      
      op2[i]<- substr(expr,op1[i],op1[i]+1)
    }
    
  }
  
  return(op2)
  
}





# To clean up the expr 
clean<- function(expr){
  t1<- gsub("h","",expr)
  return(t1)
}

#Hinge function
hinge_max<- function(df){
  t2<-replace(df, df < 0, 0)
  
  return(t2)
}






# Function for 60dimension to identify selected features from PM1
c2<-function(expr){
  
  id<- unlist(gregexpr('x',expr))
  id1<-id+1
  id2<- id + 2
  
  if(length(id)==1){
    t1<- substr(expr,id1,id1)
    t2<- substr(expr,id2,id2)
    
    t<-c(t1,t2)
    
    check<-which(c(t1 %in% 0:9,t2 %in% 0:9))
    
    t3<-t[check]
    
    if(length(t3)==2){
      
      t3<-paste0(t3[1],t3[2])
      
    }
    
    op<- paste0("x",t3)
    
  } else{  id3<-c()
  
  for (i in 1:length(id)){
    
    id3[i]<- substr(expr,id2[i],id2[i])
    
    
  }
  
  #id3<- sort(id3)
  
  temp<-which(grepl("\\d",id3))
  
  id4<-c()
  
  # if(length(temp)>0){
  # id4[1]<-substr(expr,id1[-temp],id1[-temp])
  # id4[2]<-substr(expr,id1[temp],id1[temp]+1)
  # 
  # id4<-as.numeric(id4)
  # id4<-sort(id4)
  # 
  # } else{ id4[1]<- substr(expr,id1[1],id1[1])
  #   
  # id4[2]<- substr(expr,id1[2],id1[2])
  # id4<-as.numeric(id4)
  # id4<-sort(id4)
  # }
  
  if(length(temp)==1){
    id4[1]<-substr(expr,id1[-temp],id1[-temp])
    id4[2]<-substr(expr,id1[temp],id1[temp]+1)
    
    id4<-as.numeric(id4)
    id4<-sort(id4)
    
  } else if(length(temp)==2){
    id4[1]<-substr(expr,id1[1],id1[1]+1)
    id4[2]<-substr(expr,id1[2],id1[2]+1)
    
    id4<-as.numeric(id4)
    id4<-sort(id4)
    
  } else{ id4[1]<- substr(expr,id1[1],id1[1])
  
  id4[2]<- substr(expr,id1[2],id1[2])
  id4<-as.numeric(id4)
  id4<-sort(id4)}
  
  op<-c()
  
  for(i in 1:length(id4)){
    
    op[i]<- paste0("x",id4[i])
    
    
  }
  
  
  }
  
  
  return(op) 
  
  
  
  
}

mult<- function(element){
  
  ul<- unlist(element)
  op<- paste0(element[1],'*',element[2])
  
  return(op)
}

