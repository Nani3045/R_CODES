#### Rounding method for 2 and 9 level variable

rm_modified<- function(x,n2,n4)

{
  
  ############ For 2 level factors ##################
  # Assigning sobol columns to 2 level factors  
  if(n2>0){ x2<-x[,1:n2]
  
  # Remaining sobol columns
  y<- x[,-(1:n2)]
  
  
  xconverted2<- matrix(,nrow=nrow(x2),ncol=ncol(x2))
  
  for (i in 1:ncol(x2)){
    for (j in 1:nrow(x2)){
      if (x2[j,i]> 0.5)
        xconverted2[j,i]<- 2
      else
        xconverted2[j,i]<- 1
      
    }
  }
  
  
  #### For 4 level factors #####################
  
  xconverted4<- matrix(,nrow=nrow(y),ncol=ncol(y))
  # attach(xcat)
  
  for(i in seq(from=1,to=ncol(y)-2,by=3)){
    for (j in 1:nrow(y))
      if(max(y[j,c(i:(i+2))]> 0.6299))
        #xconverted[j,i]<-print((max.col(xcat[j,c(i:(i+2))],ties.method = c("random"))))
        xconverted4[j,i]<- which.max(y[j,c(i:(i+2))])
      else
        xconverted4[j,i]<-4
  }
  
  library(janitor)
  xconv4<- data.frame(remove_empty(xconverted4))
  
  design<-cbind(xconverted2,xconv4)
  
} else {y<-x 
        
        xconverted4<- matrix(,nrow=nrow(y),ncol=ncol(y))
        # attach(xcat)
        
        for(i in seq(from=1,to=ncol(y)-2,by=3)){
          for (j in 1:nrow(y))
            if(max(y[j,c(i:(i+2))]> 0.6299))
              #xconverted[j,i]<-print((max.col(xcat[j,c(i:(i+2))],ties.method = c("random"))))
              xconverted4[j,i]<- which.max(y[j,c(i:(i+2))])
            else
              xconverted4[j,i]<-4
      }
        library(janitor)
        xconv4<- data.frame(remove_empty(xconverted4))
        
        design<-xconv4
           
        
        }  
        
  return(design)
}
