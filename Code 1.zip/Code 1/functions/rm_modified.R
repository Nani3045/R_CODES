#### Rounding method for 2 and 9 level variable

rm_modified<- function(x,n2,n3,n4,n5,n6,n7,n8,n9)

{

library(janitor)

Flag_check <- 0
  
  ############ For 2 level factors ##################
  # Assigning sobol columns to 2 level factors  
  if(n2>0){ 
  x2<-x[,1:n2]
  xconverted2<- matrix(,nrow=nrow(x2),ncol=ncol(x2))
  
  for (i in 1:ncol(x2)){
    for (j in 1:nrow(x2)){
      if (x2[j,i]> 0.5)
        xconverted2[j,i]<- 2
      else
        xconverted2[j,i]<- 1
      
    }
  }
  design<-xconverted2
  }

############ For 3 level factors ##################
# Assigning sobol columns to 3 level factors  

  n3_start<-n2+1
  n3_end<-n3_start+2*n3-1

  if(n3>0){ 
    
  x3<-x[,n3_start:n3_end]
  xconverted3<- matrix(,nrow=nrow(x3),ncol=ncol(x3))
  
  for(i in seq(from=1,to=ncol(x3)-1,by=2)){
    for (j in 1:nrow(x3))
      if(max(x3[j,c(i:(i+1))]> 0.5773))
        xconverted3[j,i]<-3
      else
        xconverted3[j,i]<- which.max(x3[j,c(i:(i+1))])     
  }
  xconv3<- data.frame(remove_empty(xconverted3))
  if(n2>0)
  {
    design<-cbind(design,xconv3)
  }
  else
  {
    design<-xconv3
  }
  }

############ For 4 level factors ##################
# Assigning sobol columns to 4 level factors  

  n4_start<-n3_end+1
  n4_end<-n4_start+3*n4-1

  if(n4>0){ 
    
  x4<-x[,n4_start:n4_end]
  xconverted4<- matrix(,nrow=nrow(x4),ncol=ncol(x4))
  
  for(i in seq(from=1,to=ncol(x4)-2,by=3)){
    for (j in 1:nrow(x4))
      if(max(x4[j,c(i:(i+2))]> 0.6299))
        xconverted4[j,i]<-4
      else
        xconverted4[j,i]<- which.max(x4[j,c(i:(i+2))])     
  }
  

  xconv4<- data.frame(remove_empty(xconverted4))
  if(n2>0 || n3>0)
  {
    design<-cbind(design,xconv4)
  }
  else
  {
    design<-xconv4
  }
  }

############ For 5 level factors ##################
# Assigning sobol columns to 5 level factors  

  n5_start<-n4_end+1
  n5_end<-n5_start+4*n5-1

  if(n5>0){ 
    
  x5<-x[,n5_start:n5_end]
  xconverted5<- matrix(,nrow=nrow(x5),ncol=ncol(x5))
  
  for(i in seq(from=1,to=ncol(x5)-3,by=4)){
    for (j in 1:nrow(x5))
      if(max(x5[j,c(i:(i+3))]> 0.66874))
        xconverted5[j,i]<-5
      else
        xconverted5[j,i]<- which.max(x5[j,c(i:(i+3))])     
  }
  

  xconv5<- data.frame(remove_empty(xconverted5))
  if(n2>0 || n3>0 || n4>0)
    design<-cbind(design,xconv5)
  else
    design<-xconv5
  }

############ For 6 level factors ##################
# Assigning sobol columns to 6 level factors  

  n6_start<-n5_end+1
  n6_end<-n6_start+5*n6-1

  if(n6>0){ 
    
  x6<-x[,n6_start:n6_end]
  xconverted6<- matrix(,nrow=nrow(x6),ncol=ncol(x6))
  
  for(i in seq(from=1,to=ncol(x6)-4,by=5)){
    for (j in 1:nrow(x6))
      if(max(x6[j,c(i:(i+4))]> 0.6988))
        xconverted6[j,i]<-6
      else
        xconverted6[j,i]<- which.max(x6[j,c(i:(i+4))])     
  }
  

  xconv6<- data.frame(remove_empty(xconverted6))
  if(n2>0 || n3>0 || n4>0 || n5>0)
    design<-cbind(design,xconv6)
  else
    design<-xconv6
  }

############ For 7 level factors ##################
# Assigning sobol columns to 7 level factors  

  n7_start<-n6_end+1
  n7_end<-n7_start+6*n7-1

  if(n7>0){ 
    
  x7<-x[,n7_start:n7_end]
  xconverted7<- matrix(,nrow=nrow(x7),ncol=ncol(x7))
  
  for(i in seq(from=1,to=ncol(x7)-5,by=6)){
    for (j in 1:nrow(x7))
      if(max(x7[j,c(i:(i+5))]> 0.7230))
        xconverted7[j,i]<-7
      else
        xconverted7[j,i]<- which.max(x7[j,c(i:(i+5))])     
  }
  

  xconv7<- data.frame(remove_empty(xconverted7))
  if(n2>0 || n3>0 || n4>0 || n5>0 || n6>0)
    design<-cbind(design,xconv7)
  else
    design<-xconv7
  }

############ For 8 level factors ##################
# Assigning sobol columns to 8 level factors  

  n8_start<-n7_end+1
  n8_end<-n8_start+7*n8-1

  if(n8>0){ 
    
  x8<-x[,n8_start:n8_end]
  xconverted8<- matrix(,nrow=nrow(x8),ncol=ncol(x8))
  
  for(i in seq(from=1,to=ncol(x8)-6,by=7)){
    for (j in 1:nrow(x8))
      if(max(x8[j,c(i:(i+6))]> 0.7430))
        xconverted8[j,i]<-8
      else
        xconverted8[j,i]<- which.max(x8[j,c(i:(i+6))])     
  }
  

  xconv8<- data.frame(remove_empty(xconverted8))
  if(n2>0 || n3>0 || n4>0 || n5>0 || n6>0 || n7>0)
    design<-cbind(design,xconv8)
  else
    design<-xconv8
  }

############ For 9 level factors ##################
# Assigning sobol columns to 9 level factors  

  n9_start<-n8_end+1
  n9_end<-n9_start+8*n9-1

  if(n9>0){ 
    
  x9<-x[,n9_start:n9_end]
  xconverted9<- matrix(,nrow=nrow(x9),ncol=ncol(x9))
  
  for(i in seq(from=1,to=ncol(x9)-7,by=8)){
    for (j in 1:nrow(x9))
      if(max(x9[j,c(i:(i+7))]> 0.7598))
        xconverted9[j,i]<-9
      else
        xconverted9[j,i]<- which.max(x9[j,c(i:(i+7))])     
  }
  

  xconv9<- data.frame(remove_empty(xconverted9))
  if(n2>0 || n3>0 || n4>0 || n5>0 || n6>0 || n7>0 || n8>0)
    design<-cbind(design,xconv9)
  else
    design<-xconv9
  }
        
  return(design)

}
